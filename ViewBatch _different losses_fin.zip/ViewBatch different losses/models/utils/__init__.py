"""
Utility functions for models.
"""
